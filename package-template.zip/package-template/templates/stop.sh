#/bin/bash
# 'Stop' business logic.
print "Executing the Stopcapability shell script."
print " - Deployment directory: $1"
return 1

