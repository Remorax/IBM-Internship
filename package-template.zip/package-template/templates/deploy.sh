#/bin/bash
# 'Deploy' business logic.
print "Executing the Deploycapability shell script."
print " - Deployment directory: $1"
return 1

