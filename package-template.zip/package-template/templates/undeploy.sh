#/bin/bash
# 'Undeploy' business logic.
print "Executing the Undeploycapability shell script."
print " - Deployment directory: $1"
return 1

