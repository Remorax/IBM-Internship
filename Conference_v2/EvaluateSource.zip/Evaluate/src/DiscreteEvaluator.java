import java.util.Enumeration;

import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.Cell;


public class DiscreteEvaluator {
	
	private int truePositives;
	private int falsePositives;
	private int falseNegatives;
	
	private double refThreshold = 0.5;
	private double matcherThreshold = 0.5;
	
	private Alignment ref;
	private Alignment matcher;

	public DiscreteEvaluator(Alignment ref, Alignment matcher, 
			double matcherThreshold) {
		
		this.ref = ref;
		this.matcher = matcher;
		this.matcherThreshold = matcherThreshold;
	}
	
	public DiscreteEvaluator(Alignment ref, Alignment matcher) {
		this.ref = ref;
		this.matcher = matcher;
	}
	
	public void eval(Object o) throws Exception {
		
		Enumeration<Cell> refCells = ref.getElements();
		
		while (refCells.hasMoreElements()) {
			
			Cell refCell = refCells.nextElement();
			
			Enumeration<Cell> matcherCells = matcher.getElements();
			boolean found = false;
			
			while (matcherCells.hasMoreElements()) {
				
				Cell matcherCell = matcherCells.nextElement();
				
				if (match(refCell, matcherCell) && 
						refCell.getStrength() >= refThreshold &&
						matcherCell.getStrength() >= matcherThreshold) {
					
					truePositives++;
					found = true;
					break;
				}
			}
			
			if (!found && refCell.getStrength() >= refThreshold) {
				falseNegatives++;
			}
		}
		
		Enumeration<Cell> matcherCells = matcher.getElements();
		
		while (matcherCells.hasMoreElements()) {
			
			Cell matcherCell = matcherCells.nextElement();
		
			refCells = ref.getElements();
			boolean found = false;
			
			while (refCells.hasMoreElements()) {
				
				Cell refCell = refCells.nextElement();
				
				if (match(refCell, matcherCell) && 
						refCell.getStrength() >= refThreshold && 
						matcherCell.getStrength() >= matcherThreshold) {
					found = true;
					break;
				}
			}
			
			if (!found && matcherCell.getStrength() >= matcherThreshold) { 
				// don't need to check the reference threshold here
				falsePositives++;
			}
		}
	}
	
	private boolean match(Cell a, Cell b) {
		
		try {
			
			if (!a.getObject1AsURI().toString().equals(
					b.getObject1AsURI().toString())) {
				return false;
			}
			
			if (!a.getObject2AsURI().toString().equals(
					b.getObject2AsURI().toString())) {
				return false;
			}
			
			if (!a.getRelation().getRelation().equals(
					b.getRelation().getRelation())) {
				return false;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return true;
	}
	
	public int getCorrect() { return truePositives; }
	public int getGuesses() { return truePositives + falsePositives; }
	public int getTruePositives() { return truePositives; }
	public int getFalsePositives() { return falsePositives; }
	public int getFalseNegatives() { return falseNegatives; }
	
	public double getPrecision() {
		return truePositives / (float) (truePositives + falsePositives);
	}
	
	public double getRecall() {
		return truePositives / (float) (truePositives + falseNegatives);
	}
	
	public double getFMeasure() {
		return (2 * getPrecision() * getRecall()) / 
				(getPrecision() + getRecall());
	}
}
