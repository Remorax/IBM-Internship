import java.io.File;
import java.io.FileReader;

import org.semanticweb.owl.align.Alignment;

import fr.inrialpes.exmo.align.parser.AlignmentParser;


public class Evaluate {
	
	public static void main(String[] args) throws Exception {
		
		if (args.length != 3) {
			System.out.println("Usage: java Evaluate <discrete | continuous> "
					+ "<reference dir> <matcher dir>");
			System.exit(1);
		}
		
		String mode = args[0];
		String ref = args[1];
		String match = args[2];
		
		AlignmentParser parser = new AlignmentParser(0);
		
		File matcherDir = new File(match);
		
		double truePositives = 0;
		double falsePositives = 0;
		double falseNegatives = 0;
		int guesses = 0;
		
		for (File matcherFile: matcherDir.listFiles()) {
			
			String testset = matcherFile.getName();
			
			if (testset.contains("DS_Store")) continue;
			
			System.out.println(testset);
			
			Alignment refAlignment = parser.parse(new FileReader(new File(
					ref + "/" + testset)));
			
			Alignment matcherAlignment = parser.parse(new FileReader(matcherFile));
			
			if (mode.equalsIgnoreCase("discrete")) {
			
				DiscreteEvaluator evaluator = new DiscreteEvaluator(
						refAlignment, matcherAlignment);
				evaluator.eval(null);

				truePositives += evaluator.getTruePositives();
				falsePositives += evaluator.getFalsePositives();
				falseNegatives += evaluator.getFalseNegatives();
				guesses += evaluator.getGuesses();
				
			} else if (mode.equalsIgnoreCase("continuous")) {
			
				ContinuousEvaluator evaluator = new ContinuousEvaluator(
						refAlignment, matcherAlignment);
				evaluator.eval(null);

				truePositives += evaluator.getWeightedTruePositives();
				falsePositives += evaluator.getWeightedFalsePositives();
				falseNegatives += evaluator.getWeightedFalseNegatives();
				
			} else {
				System.err.println("Invalid mode: choose either 'discrete' or 'continuous'");
				System.exit(1);
			}
		}
		
		double precision = truePositives / (float) (truePositives + falsePositives);
		double recall = truePositives / (float) (truePositives + falseNegatives);
		double fMeasure = (2 * precision * recall) / (precision + recall);
		
		System.out.println("\tprecision: " + precision);
		System.out.println("\trecall: " + recall);
		System.out.println("\tf-measure: " + fMeasure);
		System.out.println("\tcorrect: " + truePositives);
		System.out.println("\tguesses: " + guesses);
	}

}
