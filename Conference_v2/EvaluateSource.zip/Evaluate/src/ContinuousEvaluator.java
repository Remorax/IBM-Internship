import java.util.Enumeration;

import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.Cell;


public class ContinuousEvaluator {
	
	private double weightedTruePositives;
	private double weightedFalseNegatives;
	private double weightedFalsePositives;
	
	private Alignment ref;
	private Alignment matcher;

	public ContinuousEvaluator(Alignment ref, Alignment matcher) {
		this.ref = ref;
		this.matcher = matcher;
	}
	
	public void eval(Object o) throws Exception {
		
		Enumeration<Cell> refCells = ref.getElements();
		
		while (refCells.hasMoreElements()) {
			
			Cell refCell = refCells.nextElement();
			
			Enumeration<Cell> matcherCells = matcher.getElements();
			boolean found = false;
			
			while (matcherCells.hasMoreElements()) {
				
				Cell matcherCell = matcherCells.nextElement();
				
				if (match(refCell, matcherCell)) {

					weightedTruePositives += 
							(refCell.getStrength() * matcherCell.getStrength());
					
					if (refCell.getStrength() < matcherCell.getStrength()) {
						weightedFalsePositives += 
								(matcherCell.getStrength() - refCell.getStrength()); 
						
					} else if (refCell.getStrength() > matcherCell.getStrength()) {
						weightedFalseNegatives += 
								(refCell.getStrength() - matcherCell.getStrength());
					}
					
					found = true;
					break;
				}
			}
			
			if (!found) {
				weightedFalseNegatives += refCell.getStrength();
			}
		}
				
		Enumeration<Cell> matcherCells = matcher.getElements();
		
		while (matcherCells.hasMoreElements()) {
			
			Cell matcherCell = matcherCells.nextElement();
			
			refCells = ref.getElements();
			boolean found = false;
			
			while (refCells.hasMoreElements()) {
				
				Cell refCell = refCells.nextElement();
				
				if (match(refCell, matcherCell)) {
					found = true;
					break;
				}
			}
			
			if (!found) {
				weightedFalsePositives += matcherCell.getStrength();
			}
		}
	}
	
	private boolean match(Cell a, Cell b) {
		
		try {
			
			if (!a.getObject1AsURI().toString().equals(
					b.getObject1AsURI().toString())) {
				return false;
			}
			
			if (!a.getObject2AsURI().toString().equals(
					b.getObject2AsURI().toString())) {
				return false;
			}
			
			if (!a.getRelation().getRelation().equals
					(b.getRelation().getRelation())) {
				return false;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return true;
	}
	
	public double getWeightedTruePositives() { return weightedTruePositives; }
	public double getWeightedFalsePositives() { return weightedFalsePositives; }
	public double getWeightedFalseNegatives() { return weightedFalseNegatives; }
	
	public double getPrecision() {
		return weightedTruePositives / 
				(weightedTruePositives + weightedFalsePositives);
	}
	
	public double getRecall() {
		return weightedTruePositives / 
				(weightedTruePositives + weightedFalseNegatives);
	}
	
	public double getFMeasure() {
		return (2 * getPrecision() * getRecall()) / 
				(getPrecision() + getRecall());
	}
}
